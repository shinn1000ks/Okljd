package com.example.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.Log
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream

class PdfProcessor(private val context: Context, private val geminiApiKey: String) {
    init {
        PDFBoxResourceLoader.init(context)
    }

    suspend fun extractText(uri: Uri, onProgress: (Int, Int) -> Unit): String = withContext(Dispatchers.IO) {
        val extractedText = StringBuilder()
        
        try {
            val inputStream = context.contentResolver.openInputStream(uri)
            val pdDoc = PDDocument.load(inputStream)
            val totalPages = pdDoc.numberOfPages
            
            // Try standard PDF extraction first
            val stripper = PDFTextStripper()
            for (i in 1..totalPages) {
                stripper.startPage = i
                stripper.endPage = i
                val pageText = stripper.getText(pdDoc)
                
                if (pageText.trim().isNotEmpty()) {
                    extractedText.append(pageText).append("\n\n")
                    onProgress(i, totalPages)
                } else {
                    // Fallback to OCR using Gemini for scanned pages
                    val ocrText = extractTextWithOcr(uri, i - 1)
                    extractedText.append(ocrText).append("\n\n")
                    onProgress(i, totalPages)
                }
            }
            pdDoc.close()
        } catch (e: Exception) {
            Log.e("PdfProcessor", "Error extracting text: ${e.message}", e)
        }
        
        return@withContext extractedText.toString()
    }

    private suspend fun extractTextWithOcr(uri: Uri, pageIndex: Int): String {
        return try {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: return ""
            val renderer = PdfRenderer(pfd)
            if (pageIndex >= renderer.pageCount) return ""
            
            val page = renderer.openPage(pageIndex)
            val bitmap = Bitmap.createBitmap(
                page.width * 2, // Double resolution for better OCR
                page.height * 2,
                Bitmap.Config.ARGB_8888
            )
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()
            renderer.close()
            pfd.close()

            if (geminiApiKey.isEmpty()) {
                return "[Error: Gemini API key missing for OCR]"
            }

            val generativeModel = GenerativeModel(
                modelName = "gemini-1.5-flash",
                apiKey = geminiApiKey
            )
            val prompt = "Extract the Myanmar text from this image exactly as written. Preserve paragraphs and layout. Do not add any extra text, markdown, or translation. Only return the extracted text."
            val inputContent = content {
                image(bitmap)
                text(prompt)
            }
            val response = generativeModel.generateContent(inputContent)
            response.text ?: ""
        } catch (e: Exception) {
            Log.e("PdfProcessor", "OCR error on page $pageIndex: ${e.message}", e)
            "[OCR Error on page ${pageIndex + 1}]"
        }
    }
}
