package com.example.model

enum class CultivationRealm(
    val titleMm: String,
    val maxHp: Int,
    val maxQi: Int,
    val expRequired: Int,
    val breakthroughRate: Float,
    val description: String
) {
    QI_1("ချီစုစည်းခြင်း အဆင့် ၁", 100, 60, 100, 0.95f, "သာမန်လူသားဘဝမှ လွတ်မြောက်ကာ ပထမဆုံး ချီစွမ်းအင်ကို ခံစားသိရှိသည့် အဆင့်။"),
    QI_2("ချီစုစည်းခြင်း အဆင့် ၂", 125, 85, 160, 0.90f, "သွေးကြောများအတွင်း ချီစွမ်းအင် ချောမွေ့စွာ စီးဆင်းလာသည်။"),
    QI_3("ချီစုစည်းခြင်း အဆင့် ၃", 160, 115, 240, 0.85f, "ခန္ဓာကိုယ်ပေါ့ပါးသွက်လက်လာပြီး သာမန်လက်နက်များကို အကာအကွယ်မဲ့ ခုခံနိုင်သည်။"),
    QI_4("ချီစုစည်းခြင်း အဆင့် ၄", 200, 150, 340, 0.80f, "ချီစွမ်းအင်ကို အပြင်သို့ ထုတ်လွှတ်နိုင်စွမ်း စတင်ရရှိသည်။"),
    QI_5("ချီစုစည်းခြင်း အဆင့် ၅", 250, 190, 460, 0.75f, "ချီစွမ်းအင်ဖြင့် ရိုးရိုးလက်နက်များကို ထက်မြက်အောင် ပြုလုပ်နိုင်သည်။"),
    QI_PEAK("ချီစုစည်းခြင်း အထွတ်အထိပ်", 320, 240, 600, 0.70f, "အခြေတည်ခြင်း အဆင့်သို့ ကူးပြောင်းရန် အဆင်သင့်ဖြစ်နေသော အခြေအနေ။"),
    FOUNDATION_EARLY("အခြေတည်ခြင်း အစောပိုင်း", 420, 320, 850, 0.65f, "တာအိုအခြေခံ ခိုင်မာစွာ တည်ဆောက်ပြီး မသေမျိုးလမ်းစဉ်သို့ တရားဝင်ခြေလှမ်း စတင်ပြီ။"),
    FOUNDATION_MID("အခြေတည်ခြင်း အလယ်ပိုင်း", 540, 420, 1200, 0.60f, "ဓားပျံစီးနင်းကာ ကောင်းကင်ယံသို့ လွတ်လပ်စွာ ပျံသန်းနိုင်သည်။"),
    FOUNDATION_PEAK("အခြေတည်ခြင်း အထွတ်အထိပ်", 700, 540, 1650, 0.55f, "ရွှေအမြုတေ ဖွဲ့စည်းရန် ကောင်းကင်စွမ်းအင်များကို စုဆောင်းနေပြီ။"),
    CORE_EARLY("ရွှေအမြုတေ အစောပိုင်း", 950, 720, 2300, 0.50f, "ခန္ဓာတွင်း၌ မသေမျိုးရွှေအမြုတေ စတင်ဖြစ်ပေါ်လာသည်။ သက်တမ်းနှစ် ၅၀၀ ရှည်ကြာနိုင်သည်။"),
    CORE_PEAK("ရွှေအမြုတေ အထွတ်အထိပ်", 1300, 950, 3200, 0.45f, "ကောင်းကင်မိုးကြိုးဘေးဒဏ်ကို ရင်ဆိုင်ရမည့် အချိန်နီးကပ်လာပြီ။"),
    NASCENT_SOUL("ဝိညာဉ်သန္ဓေအဆင့်", 2000, 1500, 4800, 0.40f, "ရုပ်ခန္ဓာပျက်စီးသော်လည်း ဝိညာဉ်အဖြစ် ဆက်လက်ရှင်သန်နိုင်သော မဟာပုဂ္ဂိုလ်။"),
    IMMORTAL_ASCENSION("မသေမျိုးနတ်ဘုရားအဆင့်", 5000, 5000, 99999, 1.0f, "လောကီကန့်သတ်ချက်များမှ လုံးဝလွတ်မြောက်ကာ ကောင်းကင်ဘုံသို့ ပျံတက်သွားသော မသေမျိုး။");

    fun next(): CultivationRealm? {
        val entries = entries
        val currentIndex = entries.indexOf(this)
        return if (currentIndex < entries.size - 1) entries[currentIndex + 1] else null
    }
}

enum class SpiritualRoot(
    val titleMm: String,
    val descriptionMm: String
) {
    LIGHTNING("မိုးကြိုးဝိညာဉ်အမြစ်", "လျှပ်စီးသိုင်းစွမ်းအားပြင်းထန်ပြီး မိုးကြိုးဘေးဒဏ်ကို ခုခံနိုင်စွမ်းရှိသည်။"),
    FIRE("သန့်စင်မီးလျှံဝိညာဉ်အမြစ်", "အဖျက်စွမ်းအားကြီးမားကာ ဆေးဝါးဖော်စပ်ခြင်းနှင့် လက်နက်သွန်းလုပ်ရာတွင် ထူးချွန်သည်။"),
    WOOD("သစ်စိမ်းနတ်ဝိညာဉ်အမြစ်", "ဒဏ်ရာကုသမှုမြန်ဆန်ပြီး ချီစွမ်းအင် သိုလှောင်မှု အထူးကောင်းမွန်သည်။"),
    SWORD_BONE("ဓားရိုးတွင်းဝိညာဉ်အမြစ်", "ဓားပျံသိုင်းပညာရပ်များတွင် ထူးချွန်လွန်းသော ကောင်းကင်ပါရမီရှင်။")
}

enum class ItemType(val titleMm: String) {
    PILL("ဆေးပြား"),
    ARTIFACT("ရတနာလက်နက်"),
    TALISMAN("အင်းကွက်အဆောင်"),
    HERB("ဆေးမြက်ပင်"),
    SCRIPTURE("ကျမ်းစာ")
}

data class Item(
    val id: String,
    val name: String,
    val description: String,
    val type: ItemType,
    val price: Int,
    val hpHeal: Int = 0,
    val qiRestore: Int = 0,
    val expBonus: Int = 0,
    val breakthroughBonus: Float = 0f,
    val attackBonus: Int = 0
)

data class StoryChoice(
    val text: String,
    val nextNodeId: String,
    val requiredQi: Int = 0,
    val requiredHp: Int = 0,
    val requiredItem: String? = null,
    val hpDelta: Int = 0,
    val qiDelta: Int = 0,
    val expDelta: Int = 0,
    val stonesDelta: Int = 0,
    val rewardItem: String? = null,
    val consequence: String = ""
)

data class StoryNode(
    val id: String,
    val act: String,
    val title: String,
    val narrative: String,
    val choices: List<StoryChoice>,
    val backgroundTheme: String = "NORMAL",
    val isEnding: Boolean = false,
    val endingTitle: String? = null
)

data class InventorySlot(
    val itemId: String,
    val count: Int
)

data class JournalEntry(
    val timestamp: Long,
    val title: String,
    val note: String
)
