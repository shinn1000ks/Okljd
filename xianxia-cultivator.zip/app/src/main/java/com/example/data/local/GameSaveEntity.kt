package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "game_saves")
data class GameSaveEntity(
    @PrimaryKey val slotId: Int, // 1, 2, 3
    val playerName: String,
    val realmName: String,
    val hp: Int,
    val maxHp: Int,
    val qi: Int,
    val maxQi: Int,
    val exp: Int,
    val spiritStones: Int,
    val spiritualRootName: String,
    val currentNodeId: String,
    val inventoryJson: String,
    val journalJson: String,
    val lastEnding: String?,
    val updatedAt: Long
)
