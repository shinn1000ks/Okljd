package com.example.data

import com.example.model.Item
import com.example.model.ItemType

object ItemData {
    val items = listOf(
        Item(
            id = "qi_pill",
            name = "ချီစုဆေးပြား",
            description = "ကောင်းကင်နှင့်မြေကြီး ချီစွမ်းအင်များ စုစည်းထားသော ဆေးပြား။ ချီစွမ်းအင် ၅၀ ပြန်လည်ဖြည့်ပေးသည်။",
            type = ItemType.PILL,
            price = 30,
            qiRestore = 50
        ),
        Item(
            id = "healing_pill",
            name = "ကျောက်စိမ်းအသက်ကယ်ဆေး",
            description = "ဒဏ်ရာများကို ချက်ချင်းအသားနုတက်စေသော ဆေးပြား။ အသက်စွမ်းအင် (HP) ၇၀ ပြန်လည်ကုသပေးသည်။",
            type = ItemType.PILL,
            price = 45,
            hpHeal = 70
        ),
        Item(
            id = "breakthrough_pill",
            name = "တာအိုအဆင့်တက်နတ်ဆေး",
            description = "ကျင့်ကြံခြင်း အဆင့်တက်စမ်းသပ်ရာတွင် အောင်မြင်နှုန်း ၂၀% တိုးစေပြီး အဆိပ်အတောက်ကင်းစင်စေသည်။",
            type = ItemType.PILL,
            price = 150,
            breakthroughBonus = 0.20f
        ),
        Item(
            id = "flying_sword",
            name = "မိုးပြာတိမ်တိုက်ဓားပျံ",
            description = "မိုးပြာဓားဂိုဏ်းမှ ထုတ်လုပ်သော ဝိညာဉ်ဓားပျံ။ တိုက်ခိုက်မှုစွမ်းရည် တိုးမြှင့်ပေးပြီး ဓားသိုင်းတွင် အသုံးဝင်သည်။",
            type = ItemType.ARTIFACT,
            price = 200,
            attackBonus = 35
        ),
        Item(
            id = "dragon_talisman",
            name = "နဂါးကာကွယ်ရေးကျောက်စိမ်း",
            description = "ရှေးဟောင်းနဂါးချီပါရှိသော ကာကွယ်ရေးအဆောင်။ ပြင်းထန်သော တိုက်ခိုက်မှုများကို ကာကွယ်ပေးသည်။",
            type = ItemType.TALISMAN,
            price = 180,
            hpHeal = 40,
            breakthroughBonus = 0.10f
        ),
        Item(
            id = "spirit_herb",
            name = "ကြယ်တာရာဆေးမြက်ပင်",
            description = "ညအခါ ကြယ်ရောင်ကဲ့သို့ တလက်လက်တောက်ပသော ရှားပါးဆေးမြက်။ ရောင်းချလျှင် ဝိညာဉ်ကျောက်တုံးများစွာ ရရှိနိုင်သည်။",
            type = ItemType.HERB,
            price = 60,
            qiRestore = 25,
            expBonus = 40
        ),
        Item(
            id = "thunder_scripture",
            name = "ရှေးဟောင်းလျှပ်စီးကျမ်း",
            description = "မိုးကြိုးနတ်ဘုရား၏ လျှို့ဝှက်ကျင့်စဉ်စာအုပ်။ ကျင့်ကြံမှုအမှတ် (EXP) ၂၀၀ ချက်ချင်းရရှိစေသည်။",
            type = ItemType.SCRIPTURE,
            price = 250,
            expBonus = 200
        ),
        Item(
            id = "core_essence",
            name = "ရွှေအမြုတေအဆီအနှစ်",
            description = "ရှေးဟောင်းဂူဗိမာန်မှ ရရှိသော မဟာရတနာ။ ကျင့်ကြံမှုအမှတ် ၅၀၀ နှင့် အဆင့်တက်နှုန်း ၃၀% တိုးစေသည်။",
            type = ItemType.PILL,
            price = 500,
            expBonus = 500,
            breakthroughBonus = 0.30f
        )
    )

    private val itemMap = items.associateBy { it.id }

    fun getItem(id: String): Item? = itemMap[id]
}
