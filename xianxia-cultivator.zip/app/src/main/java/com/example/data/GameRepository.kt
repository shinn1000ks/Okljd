package com.example.data

import com.example.data.local.GameSaveDao
import com.example.data.local.GameSaveEntity
import com.example.model.CultivationRealm
import com.example.model.InventorySlot
import com.example.model.JournalEntry
import com.example.model.SpiritualRoot
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

data class GameState(
    val slotId: Int = 1,
    val playerName: String = "ကျင့်ကြံသူလေး",
    val realm: CultivationRealm = CultivationRealm.QI_1,
    val hp: Int = 100,
    val maxHp: Int = 100,
    val qi: Int = 60,
    val maxQi: Int = 60,
    val exp: Int = 0,
    val spiritStones: Int = 50,
    val spiritualRoot: SpiritualRoot = SpiritualRoot.LIGHTNING,
    val currentNodeId: String = "START",
    val inventory: List<InventorySlot> = listOf(
        InventorySlot("qi_pill", 2),
        InventorySlot("healing_pill", 1)
    ),
    val journal: List<JournalEntry> = listOf(
        JournalEntry(System.currentTimeMillis(), "တာအိုခရီးလမ်း စတင်ခြင်း", "ထျန်းယွမ်တိုက်ကြီးတွင် မသေမျိုးကျင့်ကြံရေး ခရီးစဉ်ကို စတင်ခဲ့သည်။")
    ),
    val lastEnding: String? = null,
    val lastConsequence: String? = null
)

class GameRepository(private val dao: GameSaveDao) {

    val allSaves: Flow<List<GameSaveEntity>> = dao.getAllSaves()

    suspend fun loadSave(slotId: Int): GameState? {
        val entity = dao.getSaveBySlot(slotId) ?: return null
        return entityToGameState(entity)
    }

    suspend fun saveGame(state: GameState) {
        val entity = gameStateToEntity(state)
        dao.insertOrUpdate(entity)
    }

    suspend fun deleteSave(slotId: Int) {
        dao.deleteSave(slotId)
    }

    private fun gameStateToEntity(state: GameState): GameSaveEntity {
        val invArray = JSONArray()
        for (slot in state.inventory) {
            val obj = JSONObject()
            obj.put("id", slot.itemId)
            obj.put("count", slot.count)
            invArray.put(obj)
        }

        val journalArray = JSONArray()
        for (entry in state.journal) {
            val obj = JSONObject()
            obj.put("ts", entry.timestamp)
            obj.put("title", entry.title)
            obj.put("note", entry.note)
            journalArray.put(obj)
        }

        return GameSaveEntity(
            slotId = state.slotId,
            playerName = state.playerName,
            realmName = state.realm.name,
            hp = state.hp,
            maxHp = state.maxHp,
            qi = state.qi,
            maxQi = state.maxQi,
            exp = state.exp,
            spiritStones = state.spiritStones,
            spiritualRootName = state.spiritualRoot.name,
            currentNodeId = state.currentNodeId,
            inventoryJson = invArray.toString(),
            journalJson = journalArray.toString(),
            lastEnding = state.lastEnding,
            updatedAt = System.currentTimeMillis()
        )
    }

    private fun entityToGameState(entity: GameSaveEntity): GameState {
        val realm = try {
            CultivationRealm.valueOf(entity.realmName)
        } catch (_: Exception) {
            CultivationRealm.QI_1
        }

        val root = try {
            SpiritualRoot.valueOf(entity.spiritualRootName)
        } catch (_: Exception) {
            SpiritualRoot.LIGHTNING
        }

        val inventory = mutableListOf<InventorySlot>()
        try {
            val invArray = JSONArray(entity.inventoryJson)
            for (i in 0 until invArray.length()) {
                val obj = invArray.getJSONObject(i)
                inventory.add(InventorySlot(obj.getString("id"), obj.getInt("count")))
            }
        } catch (_: Exception) {}

        val journal = mutableListOf<JournalEntry>()
        try {
            val jArray = JSONArray(entity.journalJson)
            for (i in 0 until jArray.length()) {
                val obj = jArray.getJSONObject(i)
                journal.add(
                    JournalEntry(
                        timestamp = obj.optLong("ts", System.currentTimeMillis()),
                        title = obj.optString("title", ""),
                        note = obj.optString("note", "")
                    )
                )
            }
        } catch (_: Exception) {}

        return GameState(
            slotId = entity.slotId,
            playerName = entity.playerName,
            realm = realm,
            hp = entity.hp,
            maxHp = entity.maxHp,
            qi = entity.qi,
            maxQi = entity.maxQi,
            exp = entity.exp,
            spiritStones = entity.spiritStones,
            spiritualRoot = root,
            currentNodeId = entity.currentNodeId,
            inventory = inventory,
            journal = journal,
            lastEnding = entity.lastEnding
        )
    }
}
