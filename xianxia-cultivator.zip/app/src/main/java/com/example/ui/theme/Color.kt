package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Xianxia Daoist Theme Colors
val InkDark = Color(0xFF090E17)
val InkSurface = Color(0xFF111B28)
val InkCard = Color(0xFF182638)
val InkCardBorder = Color(0xFF243952)

val JadePrimary = Color(0xFF4EE4B8)
val JadeSecondary = Color(0xFF26A69A)
val JadeDark = Color(0xFF134E3E)

val CelestialGold = Color(0xFFFFD54F)
val GoldMuted = Color(0xFFC5A059)

val CrimsonSpirit = Color(0xFFFF5376)
val QiBlue = Color(0xFF4FC3F7)
val QiCyan = Color(0xFF00E5FF)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
