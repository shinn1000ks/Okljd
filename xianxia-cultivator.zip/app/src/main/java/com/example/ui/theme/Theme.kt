package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val XianxiaColorScheme =
  darkColorScheme(
    primary = JadePrimary,
    onPrimary = InkDark,
    primaryContainer = JadeDark,
    onPrimaryContainer = JadePrimary,
    secondary = CelestialGold,
    onSecondary = InkDark,
    secondaryContainer = InkCardBorder,
    onSecondaryContainer = CelestialGold,
    tertiary = QiBlue,
    onTertiary = InkDark,
    background = InkDark,
    onBackground = TextPrimary,
    surface = InkSurface,
    onSurface = TextPrimary,
    surfaceVariant = InkCard,
    onSurfaceVariant = TextSecondary,
    outline = InkCardBorder,
    error = CrimsonSpirit,
    onError = TextPrimary,
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = XianxiaColorScheme,
    typography = Typography,
    content = content
  )
}
