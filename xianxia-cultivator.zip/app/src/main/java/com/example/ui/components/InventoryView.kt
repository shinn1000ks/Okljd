package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Healing
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameState
import com.example.data.ItemData
import com.example.model.Item
import com.example.model.ItemType
import com.example.ui.theme.CelestialGold
import com.example.ui.theme.CrimsonSpirit
import com.example.ui.theme.InkCard
import com.example.ui.theme.InkCardBorder
import com.example.ui.theme.JadePrimary
import com.example.ui.theme.QiBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun InventoryView(
    gameState: GameState,
    onUseItem: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf<ItemType?>(null) }

    val validSlots = gameState.inventory.filter { it.count > 0 }
    val filteredSlots = if (selectedFilter == null) {
        validSlots
    } else {
        validSlots.filter { slot ->
            val item = ItemData.getItem(slot.itemId)
            item?.type == selectedFilter
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(bottom = 16.dp)
            .testTag("inventory_view")
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Inventory2,
                    contentDescription = null,
                    tint = JadePrimary,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "သိုလှောင်လက်စွပ် (Storage Ring)",
                    color = CelestialGold,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Surface(
                color = Color(0xFF162635),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(
                    text = "${validSlots.sumOf { it.count }} ခု ပိုင်ဆိုင်သည်",
                    color = QiBlue,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }

        // Filter Chips Row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 6.dp)
        ) {
            item {
                FilterChip(
                    selected = selectedFilter == null,
                    onClick = { selectedFilter = null },
                    label = { Text("အားလုံး", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = JadePrimary,
                        selectedLabelColor = Color(0xFF090E17)
                    )
                )
            }
            items(ItemType.values()) { type ->
                FilterChip(
                    selected = selectedFilter == type,
                    onClick = { selectedFilter = if (selectedFilter == type) null else type },
                    label = { Text(type.titleMm, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = JadePrimary,
                        selectedLabelColor = Color(0xFF090E17)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Inventory Items List
        if (filteredSlots.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Inventory2,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "ဤအမျိုးအစားတွင် ပစ္စည်းမရှိသေးပါ",
                        color = TextMuted,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "ရတနာဆိုင် သို့မဟုတ် ဇာတ်လမ်းစွန့်စားမှုများမှ ပစ္စည်းများ စုဆောင်းနိုင်ပါသည်",
                        color = TextMuted,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filteredSlots, key = { it.itemId }) { slot ->
                    val item = ItemData.getItem(slot.itemId)
                    if (item != null) {
                        InventoryItemCard(
                            item = item,
                            count = slot.count,
                            onUse = { onUseItem(item.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun InventoryItemCard(
    item: Item,
    count: Int,
    onUse: () -> Unit
) {
    val icon = when (item.type) {
        ItemType.PILL -> Icons.Default.Healing
        ItemType.ARTIFACT -> Icons.Default.AutoAwesome
        ItemType.TALISMAN -> Icons.Default.Bookmarks
        ItemType.HERB -> Icons.Default.Spa
        ItemType.SCRIPTURE -> Icons.Default.Bookmarks
    }

    val typeColor = when (item.type) {
        ItemType.PILL -> JadePrimary
        ItemType.ARTIFACT -> CelestialGold
        ItemType.TALISMAN -> QiBlue
        ItemType.HERB -> Color(0xFF81C784)
        ItemType.SCRIPTURE -> Color(0xFFFF8A65)
    }

    val isUsable = item.type == ItemType.PILL || item.type == ItemType.SCRIPTURE || item.hpHeal > 0 || item.qiRestore > 0

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = InkCard),
        border = BorderStroke(1.dp, InkCardBorder),
        modifier = Modifier.fillMaxWidth().testTag("inventory_item_${item.id}")
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Item Icon Box
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(typeColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = typeColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Details
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = item.name,
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        color = Color(0xFF202C3C),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "x$count",
                            color = CelestialGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = item.description,
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
            }

            // Action Button
            if (isUsable) {
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onUse,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = typeColor,
                        contentColor = Color(0xFF090E17)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("use_item_${item.id}")
                ) {
                    Text(
                        text = "သုံးမည်",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
