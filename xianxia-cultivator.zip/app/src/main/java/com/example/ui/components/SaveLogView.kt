package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameState
import com.example.data.local.GameSaveEntity
import com.example.model.SpiritualRoot
import com.example.ui.theme.CelestialGold
import com.example.ui.theme.CrimsonSpirit
import com.example.ui.theme.InkCard
import com.example.ui.theme.InkCardBorder
import com.example.ui.theme.InkSurface
import com.example.ui.theme.JadePrimary
import com.example.ui.theme.QiBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SaveLogView(
    gameState: GameState,
    allSaves: List<GameSaveEntity>,
    onSaveSlot: (Int) -> Unit,
    onLoadSlot: (Int) -> Unit,
    onStartNewGame: (name: String, root: SpiritualRoot, slot: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedSubTab by remember { mutableIntStateOf(0) } // 0 = Saves, 1 = Journal Log
    var showNewGameDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(bottom = 16.dp)
            .testTag("save_log_view")
    ) {
        // Tab row
        TabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = InkCard,
            contentColor = JadePrimary,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedSubTab]),
                    color = JadePrimary
                )
            },
            modifier = Modifier.clip(RoundedCornerShape(12.dp)).padding(bottom = 12.dp)
        ) {
            Tab(
                selected = selectedSubTab == 0,
                onClick = { selectedSubTab = 0 },
                text = { Text("ဂိမ်းသိမ်းဆည်းမှု (Save Slots)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
            )
            Tab(
                selected = selectedSubTab == 1,
                onClick = { selectedSubTab = 1 },
                text = { Text("ခရီးသွားမှတ်တမ်း (Journal)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
            )
        }

        if (selectedSubTab == 0) {
            // Save Slots Screen
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "သိမ်းဆည်းထားသော အကွက်များ (၃ ခု):",
                            color = TextSecondary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        Button(
                            onClick = { showNewGameDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A32), contentColor = JadePrimary),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("new_game_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ဘဝသစ်စတင်မည်", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                items(listOf(1, 2, 3)) { slotId ->
                    val save = allSaves.find { it.slotId == slotId }
                    SaveSlotCard(
                        slotId = slotId,
                        save = save,
                        isCurrent = gameState.slotId == slotId,
                        onSave = { onSaveSlot(slotId) },
                        onLoad = { onLoadSlot(slotId) }
                    )
                }
            }
        } else {
            // Journal Entries List
            if (gameState.journal.isEmpty()) {
                Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text(text = "မှတ်တမ်း မရှိသေးပါ", color = TextMuted)
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(gameState.journal) { entry ->
                        JournalEntryCard(entry)
                    }
                }
            }
        }
    }

    if (showNewGameDialog) {
        NewGameDialog(
            onDismiss = { showNewGameDialog = false },
            onConfirm = { name, root, slot ->
                showNewGameDialog = false
                onStartNewGame(name, root, slot)
            }
        )
    }
}

@Composable
private fun SaveSlotCard(
    slotId: Int,
    save: GameSaveEntity?,
    isCurrent: Boolean,
    onSave: () -> Unit,
    onLoad: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = InkCard),
        border = BorderStroke(1.dp, if (isCurrent) JadePrimary.copy(alpha = 0.8f) else InkCardBorder),
        modifier = Modifier.fillMaxWidth().testTag("save_slot_$slotId")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Save Slot $slotId",
                        color = CelestialGold,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (isCurrent) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            color = Color(0xFF133E32),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "လက်ရှိကစားဆဲ",
                                color = JadePrimary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                if (save != null) {
                    Text(
                        text = dateFormat.format(Date(save.updatedAt)),
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            if (save != null) {
                Text(
                    text = "${save.playerName} • ${save.realmName}",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "HP: ${save.hp}/${save.maxHp} • ချီ: ${save.qi}/${save.maxQi} • ကျောက်: ${save.spiritStones}",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            } else {
                Text(
                    text = "နေရာလွတ် (သိမ်းဆည်းထားခြင်း မရှိပါ)",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(
                    onClick = onSave,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = JadePrimary),
                    border = BorderStroke(1.dp, JadePrimary),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("save_button_$slotId")
                ) {
                    Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ဒီမှာသိမ်းမည်", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                if (save != null) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onLoad,
                        colors = ButtonDefaults.buttonColors(containerColor = JadePrimary, contentColor = Color(0xFF090E17)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("load_button_$slotId")
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ပြန်ဖွင့်မည်", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun JournalEntryCard(entry: com.example.model.JournalEntry) {
    val dateFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = InkCard),
        border = BorderStroke(1.dp, InkCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = entry.title,
                    color = CelestialGold,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = dateFormat.format(Date(entry.timestamp)),
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = entry.note,
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
private fun NewGameDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, root: SpiritualRoot, slot: Int) -> Unit
) {
    var name by remember { mutableStateOf("ကျင့်ကြံသူ") }
    var selectedRoot by remember { mutableStateOf(SpiritualRoot.LIGHTNING) }
    var selectedSlot by remember { mutableIntStateOf(1) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = InkSurface,
        title = {
            Text(
                text = "ဘဝသစ် စတင်ခြင်း (New Journey)",
                color = CelestialGold,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column {
                Text(
                    text = "ကျင့်ကြံသူ နာမည်:",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = JadePrimary,
                        unfocusedBorderColor = InkCardBorder
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("new_game_name_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "ဝိညာဉ်အမြစ် ရွေးချယ်ပါ:",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(4.dp))

                SpiritualRoot.values().forEach { root ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    ) {
                        RadioButton(
                            selected = selectedRoot == root,
                            onClick = { selectedRoot = root },
                            colors = RadioButtonDefaults.colors(selectedColor = JadePrimary)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Text(text = root.titleMm, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text(text = root.descriptionMm, color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(name, selectedRoot, selectedSlot) },
                colors = ButtonDefaults.buttonColors(containerColor = JadePrimary, contentColor = Color(0xFF090E17))
            ) {
                Text("စတင်မည်", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("ပယ်ဖျက်", color = TextSecondary)
            }
        }
    )
}
