package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameState
import com.example.data.ItemData
import com.example.data.StoryData
import com.example.model.StoryChoice
import com.example.ui.theme.CelestialGold
import com.example.ui.theme.CrimsonSpirit
import com.example.ui.theme.InkCard
import com.example.ui.theme.InkCardBorder
import com.example.ui.theme.InkSurface
import com.example.ui.theme.JadePrimary
import com.example.ui.theme.QiBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun StoryView(
    gameState: GameState,
    onChoiceSelected: (StoryChoice) -> Unit,
    onReincarnate: () -> Unit,
    modifier: Modifier = Modifier
) {
    val node = StoryData.getNode(gameState.currentNodeId)
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(bottom = 24.dp)
            .testTag("story_view")
    ) {
        // Act / Chapter Badge
        Surface(
            color = Color(0xFF132B25),
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, JadePrimary.copy(alpha = 0.4f)),
            modifier = Modifier.padding(bottom = 8.dp)
        ) {
            Text(
                text = node.act,
                color = JadePrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }

        // Section Title
        Text(
            text = node.title,
            color = CelestialGold,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            lineHeight = 28.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Last Consequence Feedback Banner (if any)
        if (!gameState.lastConsequence.isNullOrEmpty()) {
            Surface(
                color = Color(0xFF1B2B38),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, QiBlue.copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Consequence",
                        tint = QiBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = gameState.lastConsequence,
                        color = Color(0xFFE2E8F0),
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )
                }
            }
        }

        // Main Narrative Parchment Card
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = InkSurface),
            border = BorderStroke(1.dp, InkCardBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = node.narrative,
                    color = TextPrimary,
                    fontSize = 15.sp,
                    lineHeight = 25.sp,
                    fontWeight = FontWeight.Normal
                )
            }
        }

        // Ending Screen if this node marks an ending
        if (node.isEnding) {
            EndingCard(
                title = node.endingTitle ?: node.title,
                onReincarnate = onReincarnate
            )
        } else {
            // Choices Section
            Text(
                text = "သင်၏ ရွေးချယ်မှု ပြုလုပ်ပါ:",
                color = TextSecondary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(bottom = 10.dp)
            )

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                node.choices.forEachIndexed { index, choice ->
                    ChoiceItem(
                        index = index,
                        choice = choice,
                        gameState = gameState,
                        onSelected = { onChoiceSelected(choice) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ChoiceItem(
    index: Int,
    choice: StoryChoice,
    gameState: GameState,
    onSelected: () -> Unit
) {
    val hasEnoughQi = choice.requiredQi == 0 || gameState.qi >= choice.requiredQi
    val hasEnoughHp = choice.requiredHp == 0 || gameState.hp >= choice.requiredHp
    val hasRequiredItem = choice.requiredItem == null || gameState.inventory.any { it.itemId == choice.requiredItem && it.count > 0 }
    val isEnabled = hasEnoughQi && hasEnoughHp && hasRequiredItem

    val borderBrush = if (isEnabled) {
        Brush.horizontalGradient(listOf(JadePrimary.copy(alpha = 0.6f), CelestialGold.copy(alpha = 0.3f)))
    } else {
        Brush.horizontalGradient(listOf(Color(0xFF333D4B), Color(0xFF28313E)))
    }

    Surface(
        color = if (isEnabled) InkCard else Color(0xFF131A24),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, borderBrush),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(enabled = isEnabled, onClick = onSelected)
            .testTag("choice_button_$index")
    ) {
        Column(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Choice Number Indicator
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(if (isEnabled) Color(0xFF1B3D34) else Color(0xFF232D3A))
                        .border(1.dp, if (isEnabled) JadePrimary else TextMuted, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${index + 1}",
                        color = if (isEnabled) JadePrimary else TextMuted,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Text(
                    text = choice.text,
                    color = if (isEnabled) TextPrimary else TextMuted,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    lineHeight = 21.sp,
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(6.dp))

                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Select",
                    tint = if (isEnabled) JadePrimary else TextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }

            // Requirements and Rewards Badges
            val hasBadges = choice.requiredQi > 0 || choice.requiredHp > 0 || choice.requiredItem != null ||
                    choice.expDelta != 0 || choice.stonesDelta != 0 || choice.rewardItem != null

            if (hasBadges) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (choice.requiredQi > 0) {
                        Badge(
                            text = "ချီ ${choice.requiredQi} လိုအပ်",
                            color = if (hasEnoughQi) QiBlue else CrimsonSpirit
                        )
                    }
                    if (choice.requiredHp > 0) {
                        Badge(
                            text = "HP ${choice.requiredHp} လိုအပ်",
                            color = if (hasEnoughHp) CrimsonSpirit else CrimsonSpirit
                        )
                    }
                    if (choice.expDelta > 0) {
                        Badge(
                            text = "+${choice.expDelta} EXP",
                            color = CelestialGold
                        )
                    }
                    if (choice.stonesDelta > 0) {
                        Badge(
                            text = "+${choice.stonesDelta} ကျောက်",
                            color = CelestialGold
                        )
                    }
                    if (choice.rewardItem != null) {
                        val itm = ItemData.getItem(choice.rewardItem)
                        Badge(
                            text = "+${itm?.name ?: "ပစ္စည်း"}",
                            color = JadePrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Badge(text: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.15f),
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(0.5.dp, color.copy(alpha = 0.4f))
    ) {
        Text(
            text = text,
            color = color,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun EndingCard(
    title: String,
    onReincarnate: () -> Unit
) {
    Surface(
        color = Color(0xFF172B23),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.5.dp, CelestialGold),
        modifier = Modifier.fillMaxWidth().testTag("ending_card")
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = "Ending",
                tint = CelestialGold,
                modifier = Modifier.size(48.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "ဇာတ်လမ်းနိဂုံး ရောက်ရှိပါပြီ",
                color = CelestialGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )

            Text(
                text = title,
                color = JadePrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 26.sp,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            Text(
                text = "သင်သည် မသေမျိုးလမ်းစဉ်၌ သမိုင်းမှတ်တိုင်တစ်ခုကို အောင်မြင်စွာ စိုက်ထူနိုင်ခဲ့သည်။ ပြန်လည်ဝင်စားခြင်းဖြင့် ရှေးဘဝအမွေအနှစ် ရတနာများနှင့်အတူ ဘဝသစ်ကို စတင်နိုင်ပါပြီ။",
                color = TextPrimary,
                fontSize = 13.sp,
                lineHeight = 21.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Button(
                onClick = onReincarnate,
                colors = ButtonDefaults.buttonColors(containerColor = CelestialGold, contentColor = Color(0xFF0D1520)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("reincarnate_button")
            ) {
                Icon(imageVector = Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "အမွေအနှစ်ဖြင့် ဘဝသစ် စတင်မည်",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
