package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GameRepository
import com.example.data.GameState
import com.example.data.ItemData
import com.example.data.StoryData
import com.example.data.local.AppDatabase
import com.example.data.local.GameSaveEntity
import com.example.model.CultivationRealm
import com.example.model.InventorySlot
import com.example.model.JournalEntry
import com.example.model.SpiritualRoot
import com.example.model.StoryChoice
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class GameTab(val titleMm: String) {
    STORY("ဇာတ်လမ်း"),
    CULTIVATION("ကျင့်ကြံခြင်း"),
    INVENTORY("သိုလှောင်အိတ်"),
    SHOP("ရတနာဆိုင်"),
    SAVES("မှတ်တမ်း/သိမ်း")
}

sealed class BreakthroughResult {
    data class Success(val message: String, val newRealm: CultivationRealm) : BreakthroughResult()
    data class Failure(val message: String) : BreakthroughResult()
}

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GameRepository

    private val _gameState = MutableStateFlow(GameState())
    val gameState: StateFlow<GameState> = _gameState.asStateFlow()

    private val _currentTab = MutableStateFlow(GameTab.STORY)
    val currentTab: StateFlow<GameTab> = _currentTab.asStateFlow()

    private val _isMeditating = MutableStateFlow(false)
    val isMeditating: StateFlow<Boolean> = _isMeditating.asStateFlow()

    private val _breakthroughResult = MutableStateFlow<BreakthroughResult?>(null)
    val breakthroughResult: StateFlow<BreakthroughResult?> = _breakthroughResult.asStateFlow()

    private val _notification = MutableStateFlow<String?>(null)
    val notification: StateFlow<String?> = _notification.asStateFlow()

    val allSaves: StateFlow<List<GameSaveEntity>>

    init {
        val db = AppDatabase.getInstance(application)
        repository = GameRepository(db.gameSaveDao())
        allSaves = repository.allSaves.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        // Try to load auto-save slot 1 on launch
        viewModelScope.launch {
            val saved = repository.loadSave(1)
            if (saved != null) {
                _gameState.value = saved
            } else {
                // Initial save
                repository.saveGame(_gameState.value)
            }
        }
    }

    fun selectTab(tab: GameTab) {
        _currentTab.value = tab
    }

    fun clearNotification() {
        _notification.value = null
    }

    fun clearBreakthroughResult() {
        _breakthroughResult.value = null
    }

    fun chooseOption(choice: StoryChoice) {
        val current = _gameState.value

        // Validation
        if (choice.requiredQi > 0 && current.qi < choice.requiredQi) {
            _notification.value = "ချီစွမ်းအင် မလုံလောက်ပါ! (အနည်းဆုံး ${choice.requiredQi} လိုအပ်သည်)"
            return
        }
        if (choice.requiredHp > 0 && current.hp < choice.requiredHp) {
            _notification.value = "အသက်စွမ်းအင် (HP) နည်းလွန်းနေပါသည်!"
            return
        }
        if (choice.requiredItem != null && current.inventory.none { it.itemId == choice.requiredItem && it.count > 0 }) {
            val reqName = ItemData.getItem(choice.requiredItem)?.name ?: "ပစ္စည်း"
            _notification.value = "$reqName လိုအပ်ပါသည်!"
            return
        }

        // Apply deltas
        var newHp = (current.hp + choice.hpDelta).coerceIn(0, current.maxHp)
        val newQi = (current.qi + choice.qiDelta).coerceIn(0, current.maxQi)
        val newExp = current.exp + choice.expDelta
        val newStones = (current.spiritStones + choice.stonesDelta).coerceAtLeast(0)

        // Rewards
        val newInventory = current.inventory.toMutableList()
        if (choice.rewardItem != null) {
            val existingIndex = newInventory.indexOfFirst { it.itemId == choice.rewardItem }
            if (existingIndex >= 0) {
                val item = newInventory[existingIndex]
                newInventory[existingIndex] = item.copy(count = item.count + 1)
            } else {
                newInventory.add(InventorySlot(choice.rewardItem, 1))
            }
        }

        val targetNode = StoryData.getNode(choice.nextNodeId)
        val nextNodeId = if (newHp <= 0) "DEATH_FALL" else choice.nextNodeId

        val newJournal = current.journal.toMutableList()
        val journalText = if (choice.consequence.isNotEmpty()) choice.consequence else choice.text
        newJournal.add(0, JournalEntry(System.currentTimeMillis(), targetNode.title, journalText))

        val updated = current.copy(
            hp = newHp,
            qi = newQi,
            exp = newExp,
            spiritStones = newStones,
            currentNodeId = nextNodeId,
            inventory = newInventory,
            journal = newJournal.take(50),
            lastConsequence = choice.consequence,
            lastEnding = if (targetNode.isEnding) targetNode.endingTitle else current.lastEnding
        )

        _gameState.value = updated
        viewModelScope.launch {
            repository.saveGame(updated)
        }
    }

    fun meditate() {
        if (_isMeditating.value) return
        viewModelScope.launch {
            _isMeditating.value = true
            delay(1200) // Brief immersive cultivation channel

            _gameState.update { current ->
                val gainedQi = when (current.spiritualRoot) {
                    SpiritualRoot.WOOD -> 30
                    else -> 22
                }
                val gainedHp = 18
                val gainedExp = 35

                val newHp = (current.hp + gainedHp).coerceAtMost(current.maxHp)
                val newQi = (current.qi + gainedQi).coerceAtMost(current.maxQi)
                val newExp = current.exp + gainedExp

                current.copy(hp = newHp, qi = newQi, exp = newExp)
            }

            _isMeditating.value = false
            _notification.value = "တရားထိုင်ခြင်း ပြီးဆုံးပါပြီ။ ချီစွမ်းအင်နှင့် အသက်သွေးအား ပြန်လည်ပြည့်ဖြိုးလာသည်။"
            repository.saveGame(_gameState.value)
        }
    }

    fun attemptBreakthrough(useBreakthroughPill: Boolean = false) {
        val current = _gameState.value
        val nextRealm = current.realm.next()

        if (nextRealm == null) {
            _notification.value = "သင်သည် မသေမျိုးအထွတ်အထိပ်သို့ ရောက်ရှိနေပြီဖြစ်ပါသည်!"
            return
        }

        if (current.exp < current.realm.expRequired) {
            _notification.value = "ကျင့်ကြံမှုအမှတ် (EXP) မပြည့်မီသေးပါ! (လိုအပ်ချက်: ${current.realm.expRequired})"
            return
        }

        var bonusRate = 0f
        val newInv = current.inventory.toMutableList()

        if (useBreakthroughPill) {
            val pillIndex = newInv.indexOfFirst { it.itemId == "breakthrough_pill" && it.count > 0 }
            if (pillIndex >= 0) {
                val slot = newInv[pillIndex]
                if (slot.count <= 1) newInv.removeAt(pillIndex) else newInv[pillIndex] = slot.copy(count = slot.count - 1)
                bonusRate += 0.25f
            }
        }

        if (current.spiritualRoot == SpiritualRoot.LIGHTNING) {
            bonusRate += 0.08f
        }

        val totalRate = (current.realm.breakthroughRate + bonusRate).coerceIn(0.1f, 0.98f)
        val roll = Random.nextFloat()

        if (roll <= totalRate) {
            // Success!
            val updated = current.copy(
                realm = nextRealm,
                maxHp = nextRealm.maxHp,
                hp = nextRealm.maxHp,
                maxQi = nextRealm.maxQi,
                qi = nextRealm.maxQi,
                exp = (current.exp - current.realm.expRequired).coerceAtLeast(0),
                inventory = newInv,
                journal = listOf(
                    JournalEntry(
                        System.currentTimeMillis(),
                        "အဆင့်တက်အောင်မြင်ခြင်း",
                        "${nextRealm.titleMm} သို့ အောင်မြင်စွာ တက်လှမ်းနိုင်ခဲ့သည်!"
                    )
                ) + current.journal
            )
            _gameState.value = updated
            _breakthroughResult.value = BreakthroughResult.Success(
                message = "ကောင်းကင်နှင့်မြေကြီး စွမ်းအင်များ စုဆုံလာသည်! ${nextRealm.titleMm} သို့ အောင်မြင်စွာ တက်လှမ်းနိုင်ခဲ့ပြီ!",
                newRealm = nextRealm
            )
            viewModelScope.launch {
                repository.saveGame(updated)
            }
        } else {
            // Failed attempt
            val damageHp = (current.maxHp * 0.25f).toInt()
            val damageQi = (current.maxQi * 0.35f).toInt()
            val updated = current.copy(
                hp = (current.hp - damageHp).coerceAtLeast(10),
                qi = (current.qi - damageQi).coerceAtLeast(0),
                inventory = newInv
            )
            _gameState.value = updated
            _breakthroughResult.value = BreakthroughResult.Failure(
                message = "တာအိုအခြေခံ တုန်လှုပ်ကာ အဆင့်တက်မှု မအောင်မြင်ခဲ့ပါ။ ခန္ဓာကိုယ်တွင်း ဒဏ်ရာ $damageHp ရရှိခဲ့သည်။"
            )
            viewModelScope.launch {
                repository.saveGame(updated)
            }
        }
    }

    fun useItem(itemId: String) {
        val current = _gameState.value
        val item = ItemData.getItem(itemId) ?: return

        val inv = current.inventory.toMutableList()
        val index = inv.indexOfFirst { it.itemId == itemId && it.count > 0 }
        if (index < 0) return

        val slot = inv[index]
        if (slot.count <= 1) inv.removeAt(index) else inv[index] = slot.copy(count = slot.count - 1)

        val newHp = (current.hp + item.hpHeal).coerceAtMost(current.maxHp)
        val newQi = (current.qi + item.qiRestore).coerceAtMost(current.maxQi)
        val newExp = current.exp + item.expBonus

        val updated = current.copy(
            hp = newHp,
            qi = newQi,
            exp = newExp,
            inventory = inv
        )
        _gameState.value = updated
        _notification.value = "${item.name} အား အသုံးပြုပြီးပါပြီ။"
        viewModelScope.launch {
            repository.saveGame(updated)
        }
    }

    fun buyItem(item: com.example.model.Item) {
        val current = _gameState.value
        if (current.spiritStones < item.price) {
            _notification.value = "ဝိညာဉ်ကျောက်တုံး မလုံလောက်ပါ! (လိုအပ်ငွေ: ${item.price})"
            return
        }

        val inv = current.inventory.toMutableList()
        val idx = inv.indexOfFirst { it.itemId == item.id }
        if (idx >= 0) {
            inv[idx] = inv[idx].copy(count = inv[idx].count + 1)
        } else {
            inv.add(InventorySlot(item.id, 1))
        }

        val updated = current.copy(
            spiritStones = current.spiritStones - item.price,
            inventory = inv
        )
        _gameState.value = updated
        _notification.value = "${item.name} ကို ဝယ်ယူပြီးပါပြီ!"
        viewModelScope.launch {
            repository.saveGame(updated)
        }
    }

    fun sellItem(itemId: String) {
        val current = _gameState.value
        val item = ItemData.getItem(itemId) ?: return

        val inv = current.inventory.toMutableList()
        val idx = inv.indexOfFirst { it.itemId == itemId && it.count > 0 }
        if (idx < 0) return

        val slot = inv[idx]
        if (slot.count <= 1) inv.removeAt(idx) else inv[idx] = slot.copy(count = slot.count - 1)

        val sellPrice = (item.price * 0.6f).toInt().coerceAtLeast(10)
        val updated = current.copy(
            spiritStones = current.spiritStones + sellPrice,
            inventory = inv
        )
        _gameState.value = updated
        _notification.value = "${item.name} အား ရောင်းချပြီး ဝိညာဉ်ကျောက်တုံး $sellPrice ရရှိခဲ့သည်။"
        viewModelScope.launch {
            repository.saveGame(updated)
        }
    }

    fun saveToSlot(slotId: Int) {
        viewModelScope.launch {
            val stateToSave = _gameState.value.copy(slotId = slotId)
            _gameState.value = stateToSave
            repository.saveGame(stateToSave)
            _notification.value = "Save Slot $slotId တွင် အောင်မြင်စွာ သိမ်းဆည်းပြီးပါပြီ!"
        }
    }

    fun loadFromSlot(slotId: Int) {
        viewModelScope.launch {
            val saved = repository.loadSave(slotId)
            if (saved != null) {
                _gameState.value = saved
                _notification.value = "Save Slot $slotId မှ ဂိမ်းကို ပြန်လည်ဖွင့်လိုက်ပါပြီ!"
            } else {
                _notification.value = "Save Slot $slotId တွင် အချက်အလက် မရှိသေးပါ!"
            }
        }
    }

    fun startNewGame(playerName: String = "ကျင့်ကြံသူလေး", root: SpiritualRoot = SpiritualRoot.LIGHTNING, slotId: Int = 1) {
        val newGame = GameState(
            slotId = slotId,
            playerName = playerName.ifBlank { "ကျင့်ကြံသူလေး" },
            realm = CultivationRealm.QI_1,
            hp = 100,
            maxHp = 100,
            qi = 60,
            maxQi = 60,
            exp = 0,
            spiritStones = 60,
            spiritualRoot = root,
            currentNodeId = "START",
            inventory = listOf(
                InventorySlot("qi_pill", 2),
                InventorySlot("healing_pill", 1)
            ),
            journal = listOf(
                JournalEntry(System.currentTimeMillis(), "ဘဝသစ် စတင်ခြင်း", "ထျန်းယွမ်တိုက်ကြီး၌ မသေမျိုးလမ်းစဉ်ကို အစမှ ပြန်လည်စတင်ခဲ့သည်။")
            ),
            lastEnding = null,
            lastConsequence = null
        )
        _gameState.value = newGame
        _currentTab.value = GameTab.STORY
        viewModelScope.launch {
            repository.saveGame(newGame)
        }
    }

    fun reincarnateBonus() {
        // Reincarnate with bonus stats from past life
        val pastStones = (_gameState.value.spiritStones / 2).coerceAtLeast(100)
        startNewGame(
            playerName = _gameState.value.playerName,
            root = _gameState.value.spiritualRoot,
            slotId = _gameState.value.slotId
        )
        _gameState.update {
            it.copy(
                spiritStones = pastStones + 100,
                inventory = it.inventory + InventorySlot("breakthrough_pill", 1)
            )
        }
        _notification.value = "ပြန်လည်ဝင်စားခြင်း အောင်မြင်သည်! ရှေးဘဝ အမွေအနှစ်အဖြစ် ကျောက်တုံးများနှင့် အဆင့်တက်နတ်ဆေး ရရှိခဲ့သည်။"
    }
}
