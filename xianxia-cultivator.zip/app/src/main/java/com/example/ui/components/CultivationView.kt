package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameState
import com.example.model.CultivationRealm
import com.example.model.SpiritualRoot
import com.example.ui.BreakthroughResult
import com.example.ui.theme.CelestialGold
import com.example.ui.theme.CrimsonSpirit
import com.example.ui.theme.InkCard
import com.example.ui.theme.InkCardBorder
import com.example.ui.theme.InkSurface
import com.example.ui.theme.JadeDark
import com.example.ui.theme.JadePrimary
import com.example.ui.theme.QiBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun CultivationView(
    gameState: GameState,
    isMeditating: Boolean,
    breakthroughResult: BreakthroughResult?,
    onMeditate: () -> Unit,
    onAttemptBreakthrough: (usePill: Boolean) -> Unit,
    onDismissBreakthroughResult: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    var usePill by remember { mutableStateOf(true) }
    val hasPill = gameState.inventory.any { it.itemId == "breakthrough_pill" && it.count > 0 }
    val nextRealm = gameState.realm.next()

    // Pulse animation for meditation & celestial aura
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )
    val auraAlpha by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.7f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "aura_alpha"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(bottom = 24.dp)
            .testTag("cultivation_view"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Celestial Meditating Aura Art
        Box(
            modifier = Modifier
                .size(190.dp)
                .padding(vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            // Radiating aura circles
            Canvas(modifier = Modifier.fillMaxSize().scale(if (isMeditating) pulseScale else 1f)) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = size.minDimension / 2f - 10.dp.toPx()

                // Outer halo
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(JadePrimary.copy(alpha = auraAlpha), Color.Transparent),
                        center = center,
                        radius = radius * 1.3f
                    ),
                    radius = radius * 1.2f,
                    center = center
                )

                // Concentric celestial array rings
                drawCircle(
                    color = CelestialGold.copy(alpha = 0.35f),
                    radius = radius * 0.92f,
                    center = center,
                    style = Stroke(width = 2.dp.toPx())
                )
                drawCircle(
                    color = JadePrimary.copy(alpha = 0.45f),
                    radius = radius * 0.75f,
                    center = center,
                    style = Stroke(width = 1.5.dp.toPx())
                )
            }

            // Inner Meditator Symbol
            Box(
                modifier = Modifier
                    .size(86.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(Color(0xFF163E34), Color(0xFF0F2620))
                        )
                    )
                    .border(2.dp, JadePrimary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (isMeditating) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(54.dp),
                        color = CelestialGold,
                        strokeWidth = 3.dp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.SelfImprovement,
                        contentDescription = "Meditate",
                        tint = JadePrimary,
                        modifier = Modifier.size(48.dp)
                    )
                }
            }
        }

        // Current Realm Header
        Text(
            text = gameState.realm.titleMm,
            color = CelestialGold,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 4.dp)
        )

        Text(
            text = gameState.realm.description,
            color = TextSecondary,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            lineHeight = 19.sp,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Meditation Card (တရားထိုင်ခြင်း)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = InkCard),
            border = BorderStroke(1.dp, InkCardBorder),
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocalFireDepartment,
                        contentDescription = null,
                        tint = QiBlue,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "တရားထိုင် ချီစုပ်ယူခြင်း",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "ကောင်းကင်နှင့် မြေကြီး၏ သဘာဝချီစွမ်းအင်များကို ခန္ဓာကိုယ်အတွင်းသို့ စုပ်ယူကာ သွေးအား၊ ချီနှင့် ကျင့်ကြံမှုအမှတ်များကို တိုးပွားစေသည်။",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onMeditate,
                    enabled = !isMeditating,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = JadePrimary,
                        contentColor = Color(0xFF090E17)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("meditate_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.SelfImprovement,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isMeditating) "ချီစွမ်းအင် စုပ်ယူနေသည်..." else "တရားထိုင်ကျင့်ကြံမည် (+ချီ၊ +HP၊ +EXP)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Realm Breakthrough Card (အဆင့်တက်စမ်းသပ်ခြင်း)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = InkCard),
            border = BorderStroke(1.dp, CelestialGold.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = CelestialGold,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "အဆင့်တက်စမ်းသပ်ခြင်း (Breakthrough)",
                            color = CelestialGold,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (nextRealm != null) {
                    // Next Realm Info
                    Surface(
                        color = InkSurface,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "နောက်အဆင့်: ${nextRealm.titleMm}",
                                color = JadePrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "အဆင့်သစ်အကျိုးကျေးဇူး: Max HP ${nextRealm.maxHp}၊ Max Qi ${nextRealm.maxQi}",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }

                    // Exp Requirement Progress
                    val isExpReady = gameState.exp >= gameState.realm.expRequired
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "ကျင့်ကြံမှု လိုအပ်ချက်:",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "${gameState.exp} / ${gameState.realm.expRequired} EXP ${if (isExpReady) " (ပြည့်မီပြီ)" else ""}",
                            color = if (isExpReady) JadePrimary else CrimsonSpirit,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { (gameState.exp.toFloat() / gameState.realm.expRequired).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = if (isExpReady) JadePrimary else CrimsonSpirit,
                        trackColor = Color(0xFF242E3D)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Breakthrough Pill Checkbox
                    if (hasPill) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                        ) {
                            Checkbox(
                                checked = usePill,
                                onCheckedChange = { usePill = it },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = CelestialGold,
                                    checkmarkColor = Color(0xFF090E17)
                                )
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "တာအိုအဆင့်တက်နတ်ဆေး သုံးမည် (+၂၅% အောင်မြင်နှုန်း)",
                                color = CelestialGold,
                                fontSize = 12.sp
                            )
                        }
                    } else {
                        Text(
                            text = "အကြံပြုချက်: ရတနာဆိုင်တွင် 'တာအိုအဆင့်တက်နတ်ဆေး' ဝယ်ယူသောက်သုံးပါက အောင်မြင်နှုန်း ၂၅% တိုးစေသည်။",
                            color = TextMuted,
                            fontSize = 11.sp,
                            lineHeight = 16.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    // Success Rate Display
                    val estimatedRate = (gameState.realm.breakthroughRate + if (hasPill && usePill) 0.25f else 0f + if (gameState.spiritualRoot == SpiritualRoot.LIGHTNING) 0.08f else 0f).coerceIn(0.1f, 0.98f)
                    Text(
                        text = "ခန့်မှန်း အောင်မြင်နိုင်ခြေ: ${(estimatedRate * 100).toInt()}%",
                        color = if (estimatedRate >= 0.7f) JadePrimary else CelestialGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Button(
                        onClick = { onAttemptBreakthrough(hasPill && usePill) },
                        enabled = isExpReady,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CelestialGold,
                            contentColor = Color(0xFF090E17),
                            disabledContainerColor = Color(0xFF28313E),
                            disabledContentColor = TextMuted
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("breakthrough_button")
                    ) {
                        Icon(imageVector = Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isExpReady) "မိုးကြိုးဒဏ်ခံယူပြီး အဆင့်တက်မည်!" else "EXP မလုံလောက်သေးပါ",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Text(
                        text = "သင်သည် မသေမျိုးနတ်ဘုရား အထွတ်အထိပ်သို့ ရောက်ရှိပြီးဖြစ်ပါသည်!",
                        color = JadePrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    // Breakthrough Result Dialog
    if (breakthroughResult != null) {
        AlertDialog(
            onDismissRequest = onDismissBreakthroughResult,
            containerColor = InkSurface,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (breakthroughResult is BreakthroughResult.Success) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (breakthroughResult is BreakthroughResult.Success) JadePrimary else CrimsonSpirit,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (breakthroughResult is BreakthroughResult.Success) "အဆင့်တက် အောင်မြင်သည်!" else "အဆင့်တက်မှု မအောင်မြင်ပါ",
                        color = if (breakthroughResult is BreakthroughResult.Success) JadePrimary else CrimsonSpirit,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Text(
                    text = when (breakthroughResult) {
                        is BreakthroughResult.Success -> breakthroughResult.message
                        is BreakthroughResult.Failure -> breakthroughResult.message
                    },
                    color = TextPrimary,
                    fontSize = 14.sp,
                    lineHeight = 22.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = onDismissBreakthroughResult,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = JadePrimary,
                        contentColor = Color(0xFF090E17)
                    )
                ) {
                    Text("လက်ခံသည်", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
