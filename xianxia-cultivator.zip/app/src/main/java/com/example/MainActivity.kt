package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.GameTab
import com.example.ui.GameViewModel
import com.example.ui.components.CultivationView
import com.example.ui.components.InventoryView
import com.example.ui.components.SaveLogView
import com.example.ui.components.ShopView
import com.example.ui.components.StatusHud
import com.example.ui.components.StoryView
import com.example.ui.theme.CelestialGold
import com.example.ui.theme.InkDark
import com.example.ui.theme.InkSurface
import com.example.ui.theme.JadePrimary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

class MainActivity : ComponentActivity() {
    private val viewModel: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                XianxiaApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun XianxiaApp(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val gameState by viewModel.gameState.collectAsStateWithLifecycle()
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val isMeditating by viewModel.isMeditating.collectAsStateWithLifecycle()
    val breakthroughResult by viewModel.breakthroughResult.collectAsStateWithLifecycle()
    val notification by viewModel.notification.collectAsStateWithLifecycle()
    val allSaves by viewModel.allSaves.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(notification) {
        notification?.let { msg ->
            snackbarHostState.showSnackbar(
                message = msg,
                duration = SnackbarDuration.Short
            )
            viewModel.clearNotification()
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(InkDark),
        containerColor = InkDark,
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(
                containerColor = InkSurface,
                contentColor = TextPrimary,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_navigation_bar")
            ) {
                GameTab.values().forEach { tab ->
                    val isSelected = currentTab == tab
                    val icon = when (tab) {
                        GameTab.STORY -> Icons.AutoMirrored.Filled.MenuBook
                        GameTab.CULTIVATION -> Icons.Default.SelfImprovement
                        GameTab.INVENTORY -> Icons.Default.Inventory2
                        GameTab.SHOP -> Icons.Default.Storefront
                        GameTab.SAVES -> Icons.Default.History
                    }

                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.selectTab(tab) },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = tab.titleMm,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                text = tab.titleMm,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = InkDark,
                            selectedTextColor = JadePrimary,
                            indicatorColor = JadePrimary,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        ),
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            // Persistent Cultivator Status HUD
            StatusHud(gameState = gameState)

            Spacer(modifier = Modifier.height(10.dp))

            // Main Active View with smooth cross-fade transition
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                AnimatedContent(
                    targetState = currentTab,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "tab_content_transition"
                ) { targetTab ->
                    when (targetTab) {
                        GameTab.STORY -> StoryView(
                            gameState = gameState,
                            onChoiceSelected = { viewModel.chooseOption(it) },
                            onReincarnate = { viewModel.reincarnateBonus() }
                        )

                        GameTab.CULTIVATION -> CultivationView(
                            gameState = gameState,
                            isMeditating = isMeditating,
                            breakthroughResult = breakthroughResult,
                            onMeditate = { viewModel.meditate() },
                            onAttemptBreakthrough = { viewModel.attemptBreakthrough(it) },
                            onDismissBreakthroughResult = { viewModel.clearBreakthroughResult() }
                        )

                        GameTab.INVENTORY -> InventoryView(
                            gameState = gameState,
                            onUseItem = { viewModel.useItem(it) }
                        )

                        GameTab.SHOP -> ShopView(
                            gameState = gameState,
                            onBuyItem = { viewModel.buyItem(it) },
                            onSellItem = { viewModel.sellItem(it) }
                        )

                        GameTab.SAVES -> SaveLogView(
                            gameState = gameState,
                            allSaves = allSaves,
                            onSaveSlot = { viewModel.saveToSlot(it) },
                            onLoadSlot = { viewModel.loadFromSlot(it) },
                            onStartNewGame = { name, root, slot ->
                                viewModel.startNewGame(name, root, slot)
                            }
                        )
                    }
                }
            }
        }
    }
}

// Retained for backward-compatibility with screenshot unit tests
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Surface(
        color = InkDark,
        modifier = modifier
    ) {
        Text(
            text = "Hello $name!",
            color = JadePrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(16.dp)
        )
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    MyApplicationTheme { Greeting("Cultivator") }
}
