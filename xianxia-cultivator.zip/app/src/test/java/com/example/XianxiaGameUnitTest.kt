package com.example

import com.example.data.ItemData
import com.example.data.StoryData
import com.example.model.CultivationRealm
import com.example.model.SpiritualRoot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class XianxiaGameUnitTest {

    @Test
    fun testRealmProgression() {
        val qi1 = CultivationRealm.QI_1
        val qi2 = qi1.next()
        assertNotNull(qi2)
        assertEquals(CultivationRealm.QI_2, qi2)

        val qiPeak = CultivationRealm.QI_PEAK
        val foundationEarly = qiPeak.next()
        assertEquals(CultivationRealm.FOUNDATION_EARLY, foundationEarly)
    }

    @Test
    fun testStoryTreeStartNode() {
        val startNode = StoryData.getNode("START")
        assertNotNull(startNode)
        assertEquals("START", startNode.id)
        assertTrue(startNode.choices.isNotEmpty())
        assertEquals("SECT_EXAM", startNode.choices[0].nextNodeId)
    }

    @Test
    fun testStoryEndingNodes() {
        val ascensionEnding = StoryData.getNode("ENDING_ASCENSION")
        assertTrue(ascensionEnding.isEnding)
        assertNotNull(ascensionEnding.endingTitle)
    }

    @Test
    fun testItemsCatalog() {
        val pill = ItemData.getItem("qi_pill")
        assertNotNull(pill)
        assertEquals(50, pill?.qiRestore)

        val sword = ItemData.getItem("flying_sword")
        assertNotNull(sword)
        assertEquals(35, sword?.attackBonus)
    }

    @Test
    fun testSpiritualRoots() {
        val roots = SpiritualRoot.values()
        assertTrue(roots.size >= 4)
    }
}
